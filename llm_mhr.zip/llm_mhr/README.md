# LLM-MHR 主实验代码

```
llm_mhr/
  config.py    维度、历史条数、训练与评测参数
  data.py      MACON 读取、历史采样、文本与硬提示拼接
  oae.py       Self-Fusion、Cross-Fusion、Router、OAE
  model.py     ViT + OAE + Flan-T5 编码 + 分类头
  train.py     BCE 训练循环
  eval.py      P@K / R@K / F1@K
configs/
  train.yaml / eval.yaml
```

流程：`load` 读 MACON，`split` 按 8:1:1 划分，`MaconDataset` 取当前帖子和
两条历史，`collate` 拼上 `Tag the micropost:` 并 tokenize；`LLMMHR` 用 OAE
融合当前与历史图像，再和文本、UID 一起送进编码器，分类头输出 hashtag logits；
`train` 用 BCE，`evaluate` 算 K=1/3/5/7 的 P/R/F1。

依赖：`torch`、`timm`、`transformers`。
