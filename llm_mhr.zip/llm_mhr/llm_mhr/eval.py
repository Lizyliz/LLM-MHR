from . import config


def prf(predicted, gold, k):
    predicted = set(predicted[:k])
    gold = set(gold)
    hit = len(predicted & gold)
    precision = hit / k
    recall = hit / max(len(gold), 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-8)
    return precision, recall, f1


def evaluate(model, loader, ks=config.TOPK):
    totals = {k: {"p": 0.0, "r": 0.0, "f": 0.0} for k in ks}
    count = 0
    for batch in loader:
        predictions = model.predict(
            batch["images"], batch["history_images"],
            batch["input_ids"], batch["attention_mask"], batch["uids"], k=max(ks),
        ).tolist()
        for row, gold in zip(predictions, batch["hashtags"]):
            for k in ks:
                p, r, f = prf(row, gold, k)
                totals[k]["p"] += p
                totals[k]["r"] += r
                totals[k]["f"] += f
            count += 1
    return {
        k: {"P": v["p"] / max(count, 1), "R": v["r"] / max(count, 1), "F1": v["f"] / max(count, 1)}
        for k, v in totals.items()
    }


def report(results):
    for k, values in results.items():
        print(f"K={k}  P={values['P']:.4f}  R={values['R']:.4f}  F1={values['F1']:.4f}")
