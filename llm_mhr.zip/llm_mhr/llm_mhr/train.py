import torch
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts

from . import config


def move(batch, device):
    batch["input_ids"] = batch["input_ids"].to(device)
    batch["attention_mask"] = batch["attention_mask"].to(device)
    return batch


def train_epoch(model, loader, optimizer):
    model.train()
    total = 0.0
    for batch in loader:
        _, loss = model(
            batch["images"], batch["history_images"],
            batch["input_ids"], batch["attention_mask"], batch["uids"],
            labels=batch["labels"],
        )
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total += loss.item()
    return total / max(len(loader), 1)


def train(model, loader, epochs=None):
    optimizer = Adam(model.trainable_parameters(), lr=config.LR)
    scheduler = CosineAnnealingWarmRestarts(optimizer, T_0=len(loader) * config.RESTART)
    for _ in range(epochs or config.EPOCHS):
        loss = train_epoch(model, loader, optimizer)
        scheduler.step()
        print(f"loss {loss:.4f}")
    return model


def save(model, path):
    torch.save({
        "project": model.project.state_dict(),
        "oae": model.oae.state_dict(),
        "uid": model.uid_embed.state_dict(),
        "head": model.head.state_dict(),
    }, path)
