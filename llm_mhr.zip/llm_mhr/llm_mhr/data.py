import json

import torch
from torch.utils.data import Dataset

from . import config


class MaconDataset(Dataset):
    def __init__(self, rows, history=config.HISTORY):
        self.rows = rows
        self.history = history

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        history = row.get("history", [])[-self.history:]
        return {
            "image": row["image"],
            "text": row["text"],
            "uid": row["uid"],
            "hashtags": row["hashtags"],
            "history_images": [item["image"] for item in history],
            "history_texts": [item["text"] for item in history],
        }


def collate(batch, tokenizer):
    texts = [f"{row['text']} {config.HARD_PROMPT}" for row in batch]
    tokens = tokenizer(texts, padding=True, truncation=True,
                       max_length=config.MAX_LEN, return_tensors="pt")
    labels = torch.zeros(len(batch), config.NUM_HASHTAGS)
    for i, row in enumerate(batch):
        labels[i, row["hashtags"]] = 1.0
    return {
        "texts": texts,
        "input_ids": tokens.input_ids,
        "attention_mask": tokens.attention_mask,
        "uids": torch.tensor([row["uid"] for row in batch]),
        "hashtags": [row["hashtags"] for row in batch],
        "labels": labels,
        "images": [row["image"] for row in batch],
        "history_images": [row["history_images"] for row in batch],
    }


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def split(rows, train=0.8, val=0.1):
    n = len(rows)
    return rows[: int(n * train)], rows[int(n * train): int(n * (train + val))], rows[int(n * (train + val)):]
