import math

import torch
import torch.nn as nn

from . import config


class SelfFusion(nn.Module):
    def __init__(self, dim=config.DIM, tokens=config.SOFT_TOKENS,
                 blocks=config.BLOCKS, heads=16):
        super().__init__()
        self.prompts = nn.Parameter(torch.randn(1, tokens, dim) * 0.02)
        self.blocks = nn.ModuleList([
            nn.TransformerEncoderLayer(dim, heads, batch_first=True, norm_first=True)
            for _ in range(blocks)
        ])
        self.norm = nn.LayerNorm(dim)

    def forward(self, current):
        prompt = self.prompts.expand(current.size(0), -1, -1)
        hidden = torch.cat([current, prompt], dim=1)
        for block in self.blocks:
            hidden = block(hidden)
        return self.norm(hidden[:, current.size(1):])


class CrossFusion(nn.Module):
    def __init__(self, dim=config.DIM, blocks=config.BLOCKS, heads=16):
        super().__init__()
        self.blocks = nn.ModuleList([
            nn.TransformerDecoderLayer(dim, heads, batch_first=True, norm_first=True)
            for _ in range(blocks)
        ])

    def forward(self, query, history):
        outputs = []
        for item in history:
            hidden = query
            for block in self.blocks:
                hidden = block(hidden, item)
            outputs.append(hidden)
        return outputs


class Router(nn.Module):
    def __init__(self, dim=config.DIM, tokens=config.HEADS, heads=config.HEADS):
        super().__init__()
        self.tokens = tokens
        self.dim = dim
        self.decompose = nn.Sequential(nn.Linear(dim, dim), nn.GELU(),
                                       nn.Linear(dim, tokens * dim))
        self.query = nn.Linear(dim, dim, bias=False)
        self.key = nn.Linear(dim, dim, bias=False)

    def _tokens(self, cls):
        return self.decompose(cls).view(*cls.shape[:-1], self.tokens, self.dim)

    def forward(self, current_cls, history_cls):
        query = self.query(self._tokens(current_cls))
        key = self.key(self._tokens(history_cls))
        score = torch.einsum("bmd,bhmd->bhm", query, key) / math.sqrt(self.dim)
        return score.mean(dim=1).softmax(dim=-1)


class OAE(nn.Module):
    def __init__(self):
        super().__init__()
        self.self_fusion = SelfFusion()
        self.cross_fusion = CrossFusion()
        self.router = Router()

    def forward(self, current, history):
        fused = self.self_fusion(current)
        if not history:
            return fused
        cross = self.cross_fusion(fused, history)
        weights = self.router(current[:, 0], torch.stack([h[:, 0] for h in history], dim=1))
        mixed = sum(weights[:, i, None, None] * cross[i] for i in range(len(cross)))
        return fused + mixed
