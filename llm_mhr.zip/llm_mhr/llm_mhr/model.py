import torch
import torch.nn as nn
import torch.nn.functional as F

from . import config
from .oae import OAE


class LLMMHR(nn.Module):
    def __init__(self, vit, llm, num_hashtags=config.NUM_HASHTAGS, num_uids=config.NUM_UIDS):
        super().__init__()
        self.vit = vit
        self.llm = llm
        self.project = nn.Linear(config.VIT_DIM, config.DIM)
        self.oae = OAE()
        self.uid_embed = nn.Embedding(num_uids, config.DIM)
        self.head = nn.Sequential(nn.Linear(config.DIM, config.DIM), nn.GELU(),
                                  nn.Linear(config.DIM, num_hashtags))

    def trainable_parameters(self):
        for module in (self.project, self.oae, self.uid_embed, self.head):
            yield from module.parameters()

    def encode(self, pixel_values):
        return self.project(self.vit(pixel_values).last_hidden_state)

    def forward(self, current_images, history_images, input_ids, attention_mask, uids, labels=None):
        current = self.encode(current_images)
        history = [self.encode(item) for item in history_images]
        visual = self.oae(current, history)

        text = self.llm.shared(input_ids) + self.uid_embed(uids).unsqueeze(1)
        inputs = torch.cat([visual, text], dim=1)
        mask = torch.cat([torch.ones(visual.shape[:2], device=attention_mask.device,
                                     dtype=attention_mask.dtype), attention_mask], dim=1)
        hidden = self.llm.encoder(inputs_embeds=inputs, attention_mask=mask).last_hidden_state

        logits = self.head(hidden.mean(dim=1))
        loss = F.binary_cross_entropy_with_logits(logits, labels.float()) if labels is not None else None
        return logits, loss

    @torch.no_grad()
    def predict(self, current_images, history_images, input_ids, attention_mask, uids, k=7):
        logits, _ = self(current_images, history_images, input_ids, attention_mask, uids)
        return logits.topk(k, dim=-1).indices

    @torch.no_grad()
    def generate(self, current_images, history_images, input_ids, attention_mask, uids, **kwargs):
        current = self.encode(current_images)
        history = [self.encode(item) for item in history_images]
        visual = self.oae(current, history)
        text = self.llm.shared(input_ids) + self.uid_embed(uids).unsqueeze(1)
        return self.llm.generate(inputs_embeds=torch.cat([visual, text], dim=1), **kwargs)
